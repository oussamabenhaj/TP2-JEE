package web;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/IMC")
public class ImcServlet extends HttpServlet {
private static final long serialVersionUID = 1L;
public ImcServlet() {
super();
// TODO Auto-generated constructor stub
}
protected void doGet (HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException {
	float taille = Float.parseFloat(request.getParameter("taille"));
    float poids = Float.parseFloat(request.getParameter("poids"));

    Imc imcCalculator = new Imc(taille, poids);

    float imc = imcCalculator.calcul();

    response.setContentType("text/html");
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head><title>Résultat de l'IMC</title></head>");
    out.println("<body>");
    out.println("<h1>Résultat de l'IMC</h1>");
    out.println("<p>IMC: " + imc + "</p>");
    out.println("</body></html>");
    }}}
