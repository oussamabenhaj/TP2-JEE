package web;

public class Imc {
    private float taille;
    private float poids;

    public Imc(float taille, float poids) {
        this.taille = taille;
        this.poids = poids;
    }

    public float calcul() {
        float tailleEnMetres = taille / 100; 
        return poids / (tailleEnMetres * tailleEnMetres);
    }
}
